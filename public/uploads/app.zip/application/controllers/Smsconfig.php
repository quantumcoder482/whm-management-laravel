<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Smsconfig extends Admin_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
        if (!$this->rbac->hasPrivilege('sms_setting', 'can_edit')) {
            access_denied();
        }
        $this->session->set_userdata('top_menu', 'System Settings');
        $this->session->set_userdata('sub_menu', 'smsconfig/index');
        $data['title'] = 'SMS Config List';
        $sms_result = $this->smsconfig_model->get();
        $data['statuslist'] = $this->customlib->getStatus();
        $data['smslist'] = $sms_result;
        $this->load->view('layout/header', $data);
        $this->load->view('smsconfig/smsList', $data);
        $this->load->view('layout/footer', $data);
    }

    public function infomatic() {
        $this->form_validation->set_error_delimiters('', '');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('api_id', 'API ID', 'required');
        if ($this->form_validation->run()) {

            $data = array(
                'type' => 'infomatic',
                'username' => $this->input->post('username'),
                'password' => $this->input->post('password'),
                'api_id' => $this->input->post('api_id'),
                'is_active' => $this->input->post('status')
            );
            $this->smsconfig_model->add($data);
            echo json_encode(array('st' => 0, 'msg' => 'Record updated successfully'));
        } else {
            $data = array(
                'username' => form_error('username'),
                'password' => form_error('password'),
                'api_id' => form_error('api_id')
            );
            echo json_encode(array('st' => 1, 'msg' => $data));
        }
    }
    
}

?>