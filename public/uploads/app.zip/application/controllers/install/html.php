<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Infomatic Student Management- Installation</title>
    <link href="<?php echo base_url(); ?>backend/images/s-favican.png" rel="shortcut icon" type="image/x-icon">
    <link href="<?php echo site_url(); ?>backend/installer_template/assets/css/reset.css" rel="stylesheet">
    <link href="<?php echo site_url(); ?>backend/installer_template/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href='<?php echo site_url(); ?>backend/installer_template/assets/css/open-sans.css' rel='stylesheet' type='text/css'>
    <link href='<?php echo site_url(); ?>backend/installer_template/assets/css/bs-overides.css' rel='stylesheet' type='text/css'>
    <link href='<?php echo site_url(); ?>backend/installer_template/assets/css/font-awesome.min.css' rel='stylesheet' type='text/css'>
    <script src="<?php echo site_url(); ?>backend/custom/jquery.min.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- danger: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
          <![endif]-->
    <style>
        body {
            font-family: Roboto, Sans-Serif, Arial;
        }

        .install-row {
            border: 1px solid #e4e5e7;
            border-radius: 2px;
            background: #fff;
            padding: 15px;
        }

        .logo {
            background: #337ab7;
            padding: 10px 0;
            display: inline-block;
            width: 100%;
            /* border-radius: 5px; */
            margin-bottom: 5px;
            box-shadow: 0 3px 6px rgba(0, 0, 0, .16), 0 3px 6px rgba(0, 0, 0, .23);
        }

        .logo img {
            display: block;
            width: 185px;
            /* margin:0 auto;*/
        }

        .control-label {
            font-weight: 600;
        }

        .padding-10 {
            padding: 10px;
        }

        .mbot15 {
            margin-bottom: 15px;
        }

        .bg-default {
            background: #7eac05 !important;
            color: #fff;
            /*border:1px solid #FF8000;*/
        }

        .bg-not-passed {
            border: 1px solid #e4e5e7;
            border-radius: 2px;
        }

        .bold {
            font-weight: 600;
        }

        .header {
            margin: 0;
            line-height: 2.0;
            color: white;
            text-align: left;
            font-weight: bold;
            padding-top: 3px;
        }

        .newbox.new-box-primary {
            border-top-color: #faa21c;
            box-shadow: 0 1px 3px rgba(0, 0, 0, .12), 0 1px 2px rgba(0, 0, 0, .24);
        }

        .newbox {
            position: relative;
            padding: 10px 20px 20px;
            border-radius: 3px;
            background: #ffffff;
            border-top: 3px solid #d2d6de;
            margin-bottom: 20px;
            width: 100%;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
            min-height: 226px;
        }

        .new-info-box {
            display: block;
            position: relative;
            min-height: 100%;
            background: #444a52;
            width: 100%;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.25);
            border-radius: 0px;
            margin-bottom: 10px;
            border: 2px solid #fff;
            color: #fff;
            padding: 5px;
        }

        .m1 {
            margin-top: 20px;
        }

        .new-info-box i {
            position: absolute;
            left: 0;
            min-width: 50px;
            min-height: 100%;
            font-size: 24px;
            background: #f38000;
            top: 0;
            text-align: center;
            padding-top: 10px;
        }

        .new-ii {
            padding-top: 13px !important
        }

        .new-info-box h5 {
            padding-left: 60px;
        }

        .form-control {
            border: 0 !important;
            border-bottom: 1px solid #ccc !important;
            border-radius: 0;
            padding: 6px 0px !important;
            box-shadow: none !important;
        }

        .form-group p {
            padding: 10px 0px 5px 5px;
            border-bottom: 1px solid #faa21c;
            height: 35px;
            margin-left: 10px;
        }
        }

        @media (min-width:768px) and (max-width:992px) {
            .new-info-box h5 {
                padding-left: 45px;
            }

            .new-info-box i {
                min-width: 45px
            }
        }

        /* Latest compiled and minified CSS included as External Resource*/

        /* Optional theme */

        /*@import url('//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-theme.min.css');*/
        .stepwizard-step p {
            margin-top: 0px;
            color: #666;
        }

        .stepwizard-row {
            display: table-row;
        }

        .stepwizard {
            display: table;
            margin-top: 30px;
            width: 100%;
            position: relative;
        }

        .stepwizard-step button[disabled] {
            /*opacity: 1 !important;
                filter: alpha(opacity=100) !important;*/
        }

        .stepwizard .btn.disabled,
        .stepwizard .btn[disabled],
        .stepwizard fieldset[disabled] .btn {
            opacity: 1 !important;
            color: #bbb;
        }

        .stepwizard-row:before {
            top: 14px;
            bottom: 0;
            position: absolute;
            content: " ";
            width: 100%;
            height: 1px;
            background-color: #ccc;
            z-index: 0;
        }

        .stepwizard-step {
            display: table-cell;
            text-align: center;
            position: relative;
        }

        .btn-circle {
            width: 30px;
            height: 30px;
            text-align: center;
            padding: 6px 0;
            font-size: 12px;
            line-height: 1.428571429;
            border-radius: 15px;
        }
    </style>
</head>

<body>
    <div class="logo">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-3">
                        <a href="<?php echo base_url(); ?>"><img src="../backend/images/s_logo.png"></a></div>
                    <div class="col-md-9">
                        <h3 class="header">Infomatic School : School Management System - Installer</h3>
                    </div>
                </div>
                <!--./col-md-12-->
            </div>
            <!--./row-->
        </div>
        <!--./container-->
    </div>
    <!--./row-->
    <div class="container">
        <div class="stepwizard">
            <div class="stepwizard-row setup-panel">
                <div class="stepwizard-step col-xs-3">
                    <a href="#step-1" type="button" class="btn <?php echo ($step == 1) ? 'btn-success' : 'btn-default'; ?> btn-circle">1</a>
                    <p><small>Requirements</small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <a href="#step-2" type="button" class="btn <?php echo ($step == 2) ? 'btn-success' : 'btn-default'; ?> btn-circle" disabled="disabled">2</a>
                    <p><small>Database</small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <a href="#step-3" type="button" class="btn <?php echo ($step == 3) ? 'btn-success' : 'btn-default'; ?> btn-circle" disabled="disabled">3</a>
                    <p><small>Install</small></p>
                </div>
                <div class="stepwizard-step col-xs-3">
                    <a href="#step-4" type="button" class="btn <?php echo ($step == 4) ? 'btn-success' : 'btn-default'; ?> btn-circle" disabled="disabled">4</a>
                    <p><small>Finish</small></p>
                </div>
            </div>
        </div>
        <div class="stepper-content">
            <?php if ($step == 1) { ?>
                <div class="panel panel-primary setup-content" id="step-1">
                    <div class="panel-heading">
                        <h3 class="panel-title">Requirement</h3>
                    </div>
                    <div class="panel-body">
                        <p><?php echo $debug; ?></p>
                        <?php if (isset($error) && $error != '') { ?>
                            <div class="alert alert-danger text-left">
                                <?php echo $error; ?>
                            </div>
                        <?php } ?>
                        <?php
                        include_once('requirements.php');
                        ?>
                    </div>
                </div>
            <?php } else if ($step == 2) { ?>
                <div class="panel panel-primary setup-content" id="step-2">
                    <div class="panel-heading">
                        <h3 class="panel-title">Database</h3>
                    </div>
                    <div class="panel-body">
                        <p><?php echo $debug; ?></p>
                        <?php if (isset($error) && $error != '') { ?>
                            <div class="alert alert-danger text-left">
                                <?php echo $error; ?>
                            </div>
                        <?php } ?>
                        <?php echo form_open($this->uri->uri_string()); ?>
                        <?php echo form_hidden('step', $step); ?>
                        <div class="form-group">
                            <label for="hostname" class="control-label">MySQL Hostname</label>
                            <p class="hostname"></p>
                            <input type="hidden" class="form-control" name="hostname">
                        </div>
                        <div class="form-group">
                            <label for="database" class="control-label">Database Name</label>
                            <p class="database"></p>
                            <input type="hidden" class="form-control" name="database">
                        </div>
                        <div class="form-group">
                            <label for="username" class="control-label">Database Username</label>
                            <p class="username"></p>
                            <input type="hidden" class="form-control" name="username">
                        </div>
                        <div class="form-group">
                            <label for="password" class="control-label">Database Password</label>
                            <p class="password"></p>
                            <input type="hidden" class="form-control" name="password">
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-success">Check Database</button>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>

            <?php }
        if ($step == 3) { ?>
                <div class="panel panel-primary setup-content" id="step-3">
                    <div class="panel-heading">
                        <h3 class="panel-title">Install</h3>
                    </div>
                    <div class="panel-body">
                        <p><?php echo $debug; ?></p>
                        <?php if (isset($error) && $error != '') { ?>
                            <div class="alert alert-danger text-left">
                                <?php echo $error; ?>
                            </div>
                        <?php } ?>
                        <?php echo form_open($this->uri->uri_string()); ?>
                        <?php echo form_hidden('step', $step); ?>
                        <h3>Admin User Details</h3>
                        <input type="hidden" class="form-control" name="super_email" id="super_email">
                        <input type="hidden" class="form-control" name="super_password" id="super_password">
                        <div class="form-group">
                            <label for="admin_email" class="control-label">Email (Login Username)</label>
                            <p class="admin_email"></p>
                            <input type="hidden" class="form-control" name="admin_email" id="admin_email" />
                        </div>
                        <div class="form-group">
                            <label for="admin_password" class="control-label">Password</label>
                            <p class="admin_password"></p>
                            <input type="hidden" class="form-control" name="admin_password" id="admin_password" />
                        </div>
                        <div class="text-right">
                            <button type="submit" class="btn btn-success">Begin Install</button>
                        </div>
                        <?php echo form_close(); ?>
                    </div>
                </div>
            <?php } else if ($step == 4) { ?>
                <div class="panel panel-primary setup-content" id="step-4">
                    <div class="panel-heading">
                        <h3 class="panel-title">Finish</h3>
                    </div>
                    <div class="panel-body">
                        <p><?php echo $debug; ?></p>
                        <?php if (isset($error) && $error != '') { ?>
                            <div class="alert alert-danger text-left">
                                <?php echo $error; ?>
                            </div>
                        <?php } ?>
                        <h4 class="bold">Installation Successful!</h4>
                        <p>Due to security reasons you must delete the install directory.</p>
                        <a href="<?php echo site_url('install/start/delete_install_dir'); ?>" class="btn btn-primary">Delete Install Directory and Login to Admin Panel</a>
                        <br><br><br><br><br><br><br>
                        <p><b>Please note that in Infomatic SMS there are two login panels -</b></p>
                        <ul style="list-style: disc; margin-left: 15px;">
                            <li><span style="color: #0084B4; padding-right: 5px;"><?php echo base_url(); ?>site/login</span> Admin Panel : this panel is used for staff like superadmin, admin, teacher, accountant, librarian, receptionist login.</li>
                            <li><span style="color: #0084B4; padding-right: 5px;"><?php echo base_url(); ?>site/userlogin</span> User Panel : this panel is used for student or parent login.</li>
                        </ul>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
    <!--./container-->
    <script>
        var url = 'http://super.infomaticsms.com/get_site_info';
        var subdomain = location.hostname;
        $.get(url, {
            subdomain: subdomain
        }, {
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE'
            },
            withCredentials: true,
            credentials: 'same-origin'
        }).then(res1 => {
            var data = res1.result;
            $("input[name='hostname']").val(data.domain);
            $("p.hostname").text(data.domain);
            $("input[name='database']").val(data.db_name);
            $("p.database").text(data.db_name);
            $("input[name='username']").val(data.db_user);
            $("p.username").text(data.db_user);
            $("input[name='password']").val(data.db_password);
            $("p.password").text(data.db_password);
            $("#super_email").val(data.super_user);
            $("#super_password").val(data.super_password);
            $("#admin_email").val(data.admin_user);
            $("p.admin_email").text(data.admin_user);
            $("#admin_password").val(data.admin_password);
            $("p.admin_password").text(data.admin_password);
        }, err => {
            console.log(err);
        })
    </script>
</body>

</html>