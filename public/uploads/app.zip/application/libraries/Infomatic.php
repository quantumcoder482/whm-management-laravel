<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Infomatic {
    private $_CI;
    public $username = "";
    public $password = "";
    function __construct($array) {
        $this->_CI = & get_instance();
        $this->username = $array['username'];
        $this->password = $array['password'];
    }

    function sendSMS($to, $message) 
    {
        $username = $this->username;
        $password = $this->password;
        $user = 'admin';
        $post = "sender=" . $user . "&mobile=" . urlencode($to) . "&message=" . urlencode($message) . "&format=json";
        $url = "http://smssendgo.infomats.net/web_distributor/api/sms.php?username=" . $username . "&password=" . $password; 
        $ch = curl_init();
        if (!$ch) {
            die("Couldn't initialize a cURL handle");
        }
        $timeout = 0;
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; WindowsNT 5.1; SV1)');
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $curlresponse = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'curl error : ' . curl_error($ch);
        } else {
            $info = curl_getinfo($ch);
            curl_close($ch);
            return  true;
        }
    }
}